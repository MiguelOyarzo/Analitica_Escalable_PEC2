# Titanic Survival Prediction

Este proyecto implementa un modelo de regresión logística para predecir la supervivencia en el Titanic. Utiliza el conjunto de datos "titanic.csv" para entrenar el modelo y realizar predicciones.

## Requisitos

- Python 3.x
- pip
